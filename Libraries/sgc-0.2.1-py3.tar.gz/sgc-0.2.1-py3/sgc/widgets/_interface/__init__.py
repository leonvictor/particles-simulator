"""
Interface classes that can be used to implement particular intefaces.
Should use multiple inheritance to inherit from the base widget and any
needed interface classes.

"""
